%%%%%%%%%%%%%%%%%%%%%%%%%%% WELCOME %%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% We make minor modifications to Piotr Dollar's Toolbox
%%% (https://github.com/pdollar/toolbox)
%%% Based on the paper "To Boost or Not to Boost? On the Limits of Boosted Trees for Object Detection",
%%% by E. Ohn-Bar and M. Trivedi, International Conference on Pattern Recognition, 2016
%%% The resulting detectors achieve ~18 miss rate (ACF++) and ~15 miss rate
%%% (LDCF++). Ultimately, this was a study of dataset properties and
%%% classifier limitations.

%%% Main experimental options in this script:
% New or old annotations on Caltech Pedestrians
% LDCF or ACF

%%% Final results on Caltech can be found in 'results_Caltech' folder

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%SETUP
PMTroot = '/home/lisa/Downloads/toolbox-master'; %SET LOCATION OF PIOTR'S TOOLBOX
dataDir =''; %SET LOCATION OF CALTECH DATA

addpath(genpath(PMTroot)); %YOU MAY NEED TO PLACE acfDetect_modified.m where acfDetect.m is

%%
octupSET = 1;
opts = acfTrain;
opts.modelDs=[50 20.5].*(2^octupSET); opts.modelDsPad=[64 32].*(2^octupSET);

%DEFAULTS
opts.pPyramid.pChns.pColor.smooth=0; opts.nWeak=[64 256 1024 4096];
opts.pBoost.discrete=0; opts.pPyramid.pChns.pGradHist.softBin=1;
opts.pPyramid.nOctUp=octupSET;
opts.pPyramid.minDs = opts.modelDs;
opts.pPyramid.pad = ceil((opts.modelDsPad-opts.modelDs)/opts.pPyramid.pChns.shrink/2)*opts.pPyramid.pChns.shrink;
opts.seed = 0;
pLoad={'lbls',{'person'},'ilbls',{'people'},'squarify',{3,.41}};
%If doing flip augmentation, should use %pLoad={'lbls',{'person'},'ilbls',{'people'},'squarify',[]};
opts.pLoad = [pLoad 'hRng',[opts.modelDs(1)./2^opts.pPyramid.nOctUp inf], 'vRng',[1 1] ];
opts.winsSave = 0;
opts.pPyramid.pChns.shrink= 4; %2^(octupSET+1);


%SET NAME
opts.name=['Caltech'];


%OUR CHANGES
opts.pBoost.pTree.maxDepth=6;
opts.pBoost.pTree.fracFtrs=1; %1/8; %1/16; %Depending on how much time you have for training
opts.nNeg=100000;
opts.nAccNeg=2*opts.nNeg;


%JITTER POSITIVE SAMPLES.
%May benefit from more, up to you. sclsRange = [1.11:0.01:1.15] or sclsRange = [1.05:0.01:1.15]
%helps ACF a bit
sclsRange = 1.1;
sclsArray = [1 1];
for j=sclsRange
    sclsArray = [sclsArray; j 1; 1 j; j j];
end
opts.pJitter=struct('flip',0,'scls',sclsArray);

%OPTION 1: Obtain new annotations from https://www.mpi-inf.mpg.de/departments/computer-vision-and-multimodal-computing/research/people-detection-pose-estimation-and-tracking/how-far-are-we-from-solving-pedestrian-detection/
bnewanno = 0;
if(bnewanno)
    opts.posGtDir =[ dataDir '/anno_train10x_alignedby_RotatedFilters'];
    opts.posImgDir=[dataDir  '/train_03_clean' '/images_clean'];
    %delete([opts.posImgDir '/' 'Thumbs.db'])
    %delete([opts.posGtDir '/' 'Thumbs.db'])
else
    %We sample every 4th video frame
    opts.posGtDir=[dataDir '/train04/annotations/' ];
    opts.posImgDir=[dataDir '/train04/images/' ];
end

%OPTION 2: LDCF84 OR ACF
bldcf = 0;
if(bldcf)
    opts.filters=[2 4];
end

detector=acfTrain_modified(opts);
%%
%Testing
pLoad={'lbls',{'person'},'ilbls',{'people'},'squarify',{3,.41}};
pModify=struct('cascThr',-1,'cascCal',.025);

if(bnewanno==0)
    imgDir = [dataDir 'test/images'];
    gtDir = [dataDir 'test/annotations'];
else
    %New annotations
    imgDir = [dataDir 'test/images'];
    gtDir = [dataDir 'test/anno_test_1xnew'];
end

bontrain = 0; %For context model
if(bontrain)
    if(bneweval==0)
        samp = '04';
        gtDir=[dataDir '/train' samp '/annotations'];
        imgDir=[dataDir '/train' samp '/images'];
    else
        gtDir=[ dataDir '/anno_train10x_alignedby_RotatedFilters'];
        imgDir=[ dataDir '/train_03_clean' '/images_clean'];
    end
    
    [miss,roc,gt,dt,pr]=acfTest_modified('name',name,'imgDir',imgDir,...
        'gtDir',gtDir,'pLoad',[pLoad, 'hRng',[50 inf],...
        'vRng',[.65 1],'xRng',[5 635],'yRng',[5 475]],...
        'pModify',pModify,'reapply',0,'show',0,'outname',[name 'approx0ontrainDets.txt']);
else
    
    [miss,roc,gt,dt,pr]=acfTest_modified('name',name,'imgDir',imgDir,...
        'gtDir',gtDir,'pLoad',[pLoad, 'hRng',[50 inf],...
        'vRng',[.65 1],'xRng',[5 635],'yRng',[5 475]],...
        'pModify',pModify,'reapply',0,'show',0,'outname',[name 'approx0Dets.txt']);
end

%%
