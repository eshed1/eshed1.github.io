function descriptor = HOG2(Imgdata)
HOG_sx = 8;
HOG_sy = 8;
HOG_sbin = 18;
HOG_tx = 8;
HOG_ty = 8;
HOG_tbin = 18;
[~, ~, nFrame] = size(Imgdata);
HOG1_s = zeros(HOG_sx*HOG_sy*HOG_sbin, nFrame);
for i = 1 : nFrame
    ImgMap = Imgdata(:,:,i);
    HOG1 = HOG(ImgMap, HOG_sx, HOG_sy, HOG_sbin);
    HOG1_s(:,i) = HOG1;
end
HOG_spatio = mean(HOG1_s, 2);
HOG_tempo = HOG(HOG1_s, HOG_tx, HOG_ty, HOG_tbin);
descriptor = [HOG_tempo ; HOG_spatio];
% descriptor = HOG_tempo;
end