clear;
clc;
load('MSRGesture3D.mat');
addpath(genpath('pmtk3-3jan11\'))
svmLOOCV_pmtk3(MSRGesture3D);

%93.03 on MSR-Hand Gesture Dataset