%Version History

% Ver 0.0: 12/5/2014 - first release

% Ver 0.1: 12/22/2014 - minor fixes to acfTrain in how subcategory samples
% are excluded. See acfTrain_subcat.m
% Clustering code has been added. 