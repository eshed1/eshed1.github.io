function svmLOOCV_liblinear(featset)
subnum = 10;
acc = zeros(subnum,1);
for k = 1 : subnum
    traindata = [];
    trainlabel = [];
    testdata = [];
    testlabel = [];
    for i = 1 : length(featset)
        if featset(i).subject ~= k
            traindata = cat(1, traindata, featset(i).HOG2);
            trainlabel = cat(1, trainlabel, featset(i).label);
        else
            testdata = cat(1, testdata, featset(i).HOG2);
            testlabel = cat(1, testlabel, featset(i).label);
        end
    end
     
   %temp = mkunitvar(centercols([traindata;testdata]));
   %traindata = mkunitvar(centercols(temp(1:size(traindata,1),:)));
   %testdata = mkunitvar(centercols(temp(size(traindata,1)+1:end,:)));
    
   traindata = mkunitvar(centercols(traindata));
   testdata = mkunitvar(centercols(testdata));
    
   model =train(trainlabel, sparse(traindata), '-s 4 -c 10');
   yHat = predict(testlabel, sparse(testdata), model);
   nerrs  = sum(yHat ~= testlabel);
   
   acc(k) = 1-nerrs/size(testlabel,1)
end
disp(['mean accuracy=' num2str(mean(acc))]);
end