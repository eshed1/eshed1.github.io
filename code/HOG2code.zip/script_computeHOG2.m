clear;
clc;
load('MSRGesture3D.mat');
for i = 1 : length(MSRGesture3D)
    disp(i);
    des = HOG2(MSRGesture3D(i).depth_part);
    MSRGesture3D(i).HOG2 = des';
end

%save MSRGesture3D.mat MSRGesture3D