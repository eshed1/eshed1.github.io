%clear;
%clc;

%Now doing with liblinear and libsvm see if difference. 
load('MSRGesture3D.mat');
addpath(genpath('liblinear-1.93\'))
svmLOOCV_liblinear(MSRGesture3D)

%93.03 on MSR-Gesture 3D Dataset






