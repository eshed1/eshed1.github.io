%%%%%%%%%%%%%%%%%%%%%%%%%%%%% SubCat Detector %%%%%%%%%%%%%%%%%%%%%%%%%%%%

% The output of the subcatDet function is a list of bounding boxes, 
% x1 y1 w h score orientation
% Orientation can be a number between 1-75. To map to 3D orientation, use
% the 'anglelist.mat' array and the orientation output mod 25, so that a
% value of 25 or 50 or 75 all map to the last entry in anglelist of 2.8903
% radians. The format is in KITTI alpha format,
%       -pi/2
%         |
% -pi <-     -> 0 
%         |
%        pi/2
% which was quantized uniformly to 25 bins.
% 
% Note that due to user requests, the models delivered here were also
% trained on instances of {'Van','Truck','Tram'} although irrelevant to the
% KITTI evaluation of 'Car' detection.

% Please cite if you end up using the detector
% @inproceedings{ohnbar14,
% title={Fast and Robust Object Detection Using Visual Subcategories},
% author={Eshed Ohn-Bar and Mohan M. Trivedi},
% booktitle={Computer Vision and Pattern Recognition Workshops}, 
% year={2014}}
% As well as some of Piotr's papers/toolbox.

% Please email me if you find bugs, or have suggestions or questions!
% eohnbar@ucsd.edu

% Compatible with Windows 7 64-bit systems

%%
%%%% Add to path Piotr's Toolbox, download from http://vision.ucsd.edu/~pdollar/toolbox/doc/
addpath(genpath('toolbox'))
%%
%input is either an image or a list of image paths
fs =bbGt('getFiles',{'imex\'});
%% Note, due to loading of the models and starting a matlabpool there may be some initial delay.
detOpts = [];
detOpts.cascThrs = -1;
detOpts.nmsOverlap = 0.3;
detOpts.stride = 4;
fastmode = 0; %fastmode = 1 => 25 subcategories. fastmode = 0 => slower due to additional subcategories, but higher quality detection.
bbs = subcatDetect(fs,detOpts,fastmode);

imshow(fs{2})
bbApply('draw',bbs{2})