%Note: the code is not identical to the development version I was using in
%submitting the results to the KITTI board, so there may be some small
%flactuations (about 4 AP points it seems). The main differences come from employing Piotr's Matlab Toolbox (PMT) 
%loading and handling of subcategory training with opts.pLoad, instead of
%ours which was written from scratch.
%This will be updated in the future.

%If you find the code useful, please cite the associated CVPRW
%paper as well as Piotr's papers.
% @inproceedings{ohnbar14,
% title={Fast and Robust Object Detection Using Visual Subcategories},
% author={Eshed Ohn-Bar and Mohan M. Trivedi},
% booktitle={Computer Vision and Pattern Recognition Workshops-Mobile Vision}, 
% year={2014}
% }

%12/5/2014
%%
%Step 1: download the PMT, http://vision.ucsd.edu/~pdollar/toolbox/doc/, and make the following
%changes in acfTrain:
%a) line 222: opts.pLoad.squarify{2}=opts.modelDs(2)/opts.modelDs(1);
%should be commented out so it reads %opts.pLoad.squarify{2}=opts.modelDs(2)/opts.modelDs(1);
%b) line 300: comment the 'assert' call, so it read %assert(all(abs(bbs(:,3)./bbs(:,4)-r)<1e-5));

pmtroot = 'C:\toolbox-master\';   %SET THIS
addpath(genpath(pmtroot));

kittiroot = 'C:\KITTI\devkit_obj';   %SET THIS   
addpath(genpath(kittiroot));

%%
%Step 2: Write the KITTI dataset in PMT format

%%%%%%%%% SET DIRECTORY FOR DATASET %%%%%%%%
outdir = 'C:/eshed/kitti'; %Location to create pos and postGt, the PMT version of the dataset 
root_dir  = 'C:/KITTI/object_challenge/'; %Location of the downloaded KITTI dataset
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

rootlabels = fullfile(root_dir,'labels_2/training/label_2');
rootims = fullfile(root_dir,'image_2/training/image_2');

%We use `moderate' test settings in training. 
minboxheight = 25;
occlusionLevel = [0:1]; % [0:2] 0 = fully visible, 1 = partly occlud 2 = largely occluded, 3 = unknown
Maxtruncation = 0.3; % Percentage, from 0 to 1.
labels = {'Car'}; %can do {'Car','Truck','Van'} for adding these to training, but not needed for KITTI evaluation
B = 25; %Number of orientation clusters. Up to 20-25 should increase performance.
%% Takes about 1-2minutes due to copying images - feel free to change here for speed.
writePiotrFormat
%%
%Get model dimensions from pre-collected object statistics
objlist = load('objlist.mat');
objlist = objlist.objlist; %format is alpha x y w h
%%
[labelsquant,anglelist] = quantizeAngles(objlist(:,1),B);
clust_ar = [];
for i_clust =1:B
    aspectsr =objlist(labelsquant==i_clust,5)./objlist(labelsquant==i_clust,4);
    clust_ar(i_clust)=[mean(aspectsr)];
end
%%
%Base model size.
%(Training detectors at multiple model sizes, 32, 48, etc. is good for performance)
xx=32; 
%%
for ori_i = 1:B
    %%
yy = round(xx*clust_ar(ori_i));
opts=acfTrain();
opts.name=[outdir '/model' sprintf('%02d',ori_i)];
if(exist([opts.name 'Detector.mat'],'file')>0); delete([opts.name 'Detector.mat']); end
opts.posGtDir=[outdir '/posGt'];
opts.posImgDir=[outdir '/pos'];

opts.modelDs=[xx yy];
opts.modelDsPad = round(opts.modelDs+opts.modelDs/8);    
    
opts.nWeak=[32 128 512 2048]; opts.pBoost.pTree.fracFtrs=1/16;
opts.pNms.overlap = 0.3;
%%
inclustlabels = sprintf('car%02d',ori_i);
allBs = 1:B;  allBs(ori_i) = [];
outclustlabels = [];
for j_B = 1:length(allBs); outclustlabels{j_B} = sprintf('car%02d',allBs(j_B)); end; 
outclustlabels{end+1} = 'ig';
opts.pLoad={ 'lbls', {inclustlabels},'ilbls',{'ig'},'squarify',[]}; 
%%
opts.pJitter=struct('flip',0); opts.pNms.ovrDnm = 'union';
%opts.pPyramid.nPerOct=10;
opts.pPyramid.pChns.pGradHist.softBin=1;
opts.pPyramid.pChns.pColor.smooth=0;
opts.pBoost.pTree.maxDepth=2;
opts.pPyramid.pChns.shrink =2; %2 or 4. 2 gives better accuracy.

detector = acfTrain(opts);
end
%%
%Test on an image
clear dets
opts = []; opts.pNms.type  = 'maxg'; opts.pNms.ovrDnm  = 'union';  opts.pNms.overlap = 0.3;
for ori_i = 1:B
    currname=[outdir '/model' sprintf('%02d',ori_i)];
    currdet = load([currname 'Detector.mat']);
    currdet = acfModify(currdet.detector,'cascThr',-1,'cascCal',0,'pNms', opts.pNms);
    currdet.opts.pPyramid.nPerOct=10;
    dets{ori_i} = currdet;
end
%%
I = imread([outdir '/pos/000006.png']);
bbs = acfDetect(I,dets);
imshow(I); bbApply('draw',bbs);