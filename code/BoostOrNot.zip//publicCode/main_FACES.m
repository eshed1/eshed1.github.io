%%
%Train on WIDER Faces dataset (http://mmlab.ie.cuhk.edu.hk/projects/WIDERFace/)

%%% EXPERIMENTAL SETUP
%Convert to PMT format first
%Train face detection model (need to set some directory locations here)

%%
% Convert 'train' folder in WIDER to Piotr's toolbox format
% Run also for validation set

dataRoot = 'pmt/';
mkdir(dataRoot);
mkdir([dataRoot '/train/images/']);
mkdir([dataRoot '/train/annotations/']);

d_tr = load('wider_face_train.mat');


trevents = d_tr.event_list;
trfiles = d_tr.file_list;
trbbs = d_tr.face_bbx_list;
if(size(trfiles,1)~=size(trevents,1)); disp('warning'); pause; end
parfor i_e = 1:length(trevents)
    currfiles = trfiles{i_e};
    currbbs = trbbs{i_e};
    for i_f = 1:length(currfiles)
        fname = currfiles{i_f};
        fnameout = [fname '_' sprintf('%.2d',i_e)];
        currf = ['WIDER_train/images/' trevents{i_e} '/' fname '.jpg' ];
        %I = imread(currf); pause
        tempbb = currbbs{i_f};
        nbb = size(tempbb,1);
        
        Ilabs = {}; %For each box
        for i_bb = 1:nbb
            Ilabs{i_bb} = 'face';
        end
        
        %write current image in piotr format only load certain scale ranges
        %at a time. otherwise should be different category. do later.
        %Can load them by scale later. and by aspect. great. no orientation
        %so we can flip.
        %
        inImg = fullfile(['/home/cvrr/Downloads/wider/' currf]);
        outImg = fullfile(dataRoot,'train','images',[fnameout '.jpg']);
        system(sprintf('ln -s %s %s',inImg,outImg));
        %%
        fileID = fopen(fullfile(dataRoot,'train','annotations',[fnameout '.txt']),'w+');
        fprintf(fileID, '%% bbGt version=3\n');
        for j_a = 1:nbb
            if(isempty(Ilabs{j_a}))
                disp('warning: empty label'); pause
            else
                fprintf(fileID, '%s %d %d %d %d 0 0 0 0 0 0 0\n',Ilabs{j_a},tempbb(j_a,1),tempbb(j_a,2),tempbb(j_a,3),tempbb(j_a,4));
            end
        end
        fclose(fileID);
    end
end
%%
%Run above for validation set by setting in the right places
% d_tr = load('wider_face_val.mat');
% currf = ['WIDER_val/images/' trevents{i_e} '/' fname '.jpg' ];
% outImg = fullfile(dataRoot,'val','images',[fnameout '.jpg']);
% fileID = fopen(fullfile(dataRoot,'val','annotations',[fnameout '.txt']),'w+');
% etc...
%%
%We created a trainval joint dataset used for training/obtaining aspect
%ratios of components

dataDir = 'pmt';

fs=bbGt('getFiles',{'pmt_trainval/images/'});
fsgt=bbGt('getFiles',{'pmt_trainval/annotations/'});
nfs = length(fs);
gts = cell(1,nfs);

allbbs = [];
for i=1:nfs
    pLoad = [];
    currname = fs{i};
    idxf = find(currname=='/' | currname == '\',1,'last');
    tempname = currname(idxf+1:end-4);
    [objs,bbs] = bbGt( 'bbLoad', ['pmt_trainval/annotations/' tempname '.txt']);
    allbbs= [allbbs;bbs];
    %  imshow(fs{i}); bbApply('draw',bbs)
end
%%
validation=0;
dataDir =  '';
bfilt = 0;

for dd=9
    opts=acfTrain_modified();
    modelh = 120;
    
    tempbbs = allbbs;
    tempbbs = tempbbs(tempbbs(:,4)>=modelh,:);
    tempbbs(tempbbs(:,3) == 0,:) = [];
    
    Nmix = 3; %ON FDDB we train 3 components at 3 heights starting from 120 and halving height until smallest height times 2 in the dataset (since upsample one octave)
    rand('seed',0); prm= []; prm.outFrac = 0.05; prm.nTrial = 4;
    [clustidx,ar] = kmeans2(tempbbs(:,4)./tempbbs(:,3),Nmix,prm);
    
    if(validation)
        %VALIDATION SETTINGS
        ar = 1.3649;
        Nmix = 1;
    end
    
    for i_mix = 1:Nmix
        
        modelw = round(modelh/ar(i_mix));
        opts.modelDs=[modelh modelw]
        opts.modelDsPad=round(0.125*opts.modelDs)+opts.modelDs;
        
        opts.pPyramid.pChns.pColor.smooth=0;
        opts.pPyramid.pChns.pGradHist.softBin=1;
        opts.nWeak=[256 1024 1024*2 1024*4 4096*4];
        opts.pBoost.pTree.maxDepth=dd;
        opts.pBoost.discrete=0;
        opts.pBoost.pTree.fracFtrs=1/16;
        
        opts.nNeg=25000*20; opts.nAccNeg=50000*20;
        opts.pJitter=struct('flip',1,'scls',[1 1;1.1 1; 1 1.1; 1.1 1.1]);
        if(validation)
            opts.nNeg=25000*2; opts.nAccNeg=50000*2; %Faster for validation!
            opts.posGtDir=['wider/pmt_wimages' '/train' '/annotations/'];
            opts.posImgDir=['wider/pmt_wimages' '/train' '/images/'];
            opts.name=['models/val/valsettings_d' num2str(dd) 'h' num2str(modelh) 'w' num2str(modelw) 'NMIX' num2str(Nmix)];
            
        else
            opts.posGtDir=[ 'pmt_trainval' '/annotations'];
            opts.posImgDir=[ 'pmt_trainval' '/images'];
            opts.name=['models/trainval/trainval_16kweaks_d' num2str(dd) 'h' num2str(modelh) 'w' num2str(modelw) 'NMIX' num2str(Nmix)];
            
            if(modelh>120)
                disp('warning! requires lots of memory'); pause %Requires lots of memory
            end
            
        end
        opts.pPyramid.pChns.shrink=4;
        opts.pPyramid.nOctUp=1;
        
        pNms = []; pNms.type = 'maxg'; pNms.overlap = 0.5; pNms.ovrDnm = 'min';
        opts.pNms = pNms;
        
        pLoad={'lbls',{'face'},'ilbls',{'people'},'squarify',[]};
        opts.pLoad = [pLoad 'hRng',[modelh/2^(opts.pPyramid.nOctUp) inf], 'vRng',[1 1] ];   %May impact
        
        opts.winsSave = 0;
        
        if(bfilt)
            if(validation)
                opts.name=['models/val/LDCF_d' num2str(dd) 'h' num2str(modelh) 'w' num2str(modelw) 'NMIX' num2str(Nmix)];
            else
                opts.name=['models/trainval/LDCF_' num2str(dd) 'h' num2str(modelh) 'w' num2str(modelw) 'NMIX' num2str(Nmix)];
                
            end
            opts.filters=[3 2]; %useing 2 filtering operations of [-1 1] horizontally and vertically works well as well. see acfTrain_modified for that option
            detector = acfTrain_modified( opts );
        else
            
            detector = acfTrain_modified( opts );
        end
    end
end


%%
name = 'models/val/LDCF';
pLoad={'lbls',{'face'},'ilbls',{'people'},'squarify',{3,.41}};
%pModify=struct('cascThr',-1,'cascCal',.025);
pModify=struct('cascThr',-1,'cascCal',.0); %Otherwise it may be slow

dataDir = '';
imgDir = [dataDir 'val/images'];
gtDir = [dataDir 'val/annotations'];

[miss,roc,gt,dt,pr]=acfTest_modified('name',name,'imgDir',imgDir,...
    'gtDir',gtDir,'pLoad',[pLoad, 'hRng',[60 inf]],'pModify',pModify,...
    'reapply',0,'show',0); %,'outname',[name 'noapproxDets.txt']);
miss
trapz(pr(:,2),pr(:,3))






