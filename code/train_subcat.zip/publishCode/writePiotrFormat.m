mkdir([outdir '/pos']);
mkdir([outdir '/neg']);
mkdir([outdir '/posGt']);

s_f = 0; e_f = 7480; %Train on the entire training dataset
allidx = s_f:e_f; 

parfor i=allidx
    
    disp([num2str(i) ' Out of ' num2str(length(allidx))]);
    train_objects = readLabels(rootlabels,i); 

    I = imread(sprintf('%s/%06d.png',rootims,i));
 
    %For each object in the image, determine ignore or not and orientation cluster
    Ilabs = []; Ibbs = [];
    for obj_i = 1:length(train_objects);
        currbb = [train_objects(obj_i).x1 train_objects(obj_i).y1 train_objects(obj_i).x2 train_objects(obj_i).y2];
        currbb(currbb<1)=1;
        currbb = bbox_to_xywh(currbb); 
        
        if(sum(strcmp(train_objects(obj_i).type,labels))>0 ...
                && currbb(1,4)>minboxheight ...
                && sum(train_objects(obj_i).occlusion==occlusionLevel)>0 ...
                &&  train_objects(obj_i).truncation <= Maxtruncation)
            
            %Determine label cluster
            [labelsquant,~] = quantizeAngles(double(train_objects(obj_i).alpha),B);
             Ilabs{obj_i} = sprintf('car%02d',labelsquant);
        else
            %Ignore label
            Ilabs{obj_i} = 'ig';
        end
        Ibbs(obj_i,:) = currbb;
    end
    
    %Write
    fname = sprintf('%.6d', i);
    imwrite(I,[outdir '/pos/' fname '.png']);
    fileID = fopen([outdir '/posGT/' fname '.txt'],'w');
    fprintf(fileID, '%% bbGt version=3\n');
    for j_a = 1:size(Ibbs,1)
        fprintf(fileID, '%s %d %d %d %d 0 0 0 0 0 0 0\n',Ilabs{j_a},Ibbs(j_a,1),Ibbs(j_a,2),Ibbs(j_a,3),Ibbs(j_a,4));
    end
    fclose(fileID);
    %%
end