%If you find the code useful, please cite the associated CVPRW
%paper as well as Piotr's papers.
% @inproceedings{ohnbar14,
% title={Fast and Robust Object Detection Using Visual Subcategories},
% author={Eshed Ohn-Bar and Mohan M. Trivedi},
% booktitle={Computer Vision and Pattern Recognition Workshops-Mobile Vision}, 
% year={2014}
% }

% and/or the tech report on http://cvrr.ucsd.edu/eshed/papers/VehicleDetection_Report.pdf
%%
%Step 1: Set paths/training settings
globals
%%
%Step 2: Write the KITTI dataset in PMT format
%%%%%%%%% SET DIRECTORY FOR DATASET %%%%%%%%
outdir = 'C:/eshed/kitti'; %Location to create pos and postGt, the PMT version of the dataset 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Takes about 1-2minutes due to copying images - feel free to change here for speed.
writePiotrFormat
%%
%Step 3: get model dimensions from pre-collected object statistics
objlist = load('objlist.mat');
objlist = objlist.objlist; %format is alpha x y w h

[labelsquant,anglelist] = quantizeAngles(objlist(:,1),B);
clust_ar = [];
for i_clust =1:B
    aspectsr =objlist(labelsquant==i_clust,5)./objlist(labelsquant==i_clust,4);
    clust_ar(i_clust)=[mean(aspectsr)];
end
%%
%Step 4: Train

%Base model size.
%(Training detectors at multiple model sizes, 32, 48, etc. is good for performance)
xx=32; 

for ori_i = 1:B
yy = round(xx*clust_ar(ori_i));
opts=acfTrain();
opts.name=[outdir '/model' sprintf('%02d',ori_i)];
if(exist([opts.name 'Detector.mat'],'file')>0); delete([opts.name 'Detector.mat']); end
opts.posGtDir=[outdir '/posGt'];
opts.posImgDir=[outdir '/pos'];

opts.modelDs=[xx yy];
opts.modelDsPad = round(opts.modelDs+opts.modelDs/8);    
    
opts.nWeak=[32 128 512 2048]; opts.pBoost.pTree.fracFtrs=1/16;
opts.pNms.overlap = 0.3;
%%
inclustlabels = sprintf('car%02d',ori_i);
allBs = 1:B;  allBs(ori_i) = [];
outclustlabels = [];
for j_B = 1:length(allBs); outclustlabels{j_B} = sprintf('car%02d',allBs(j_B)); end; 
outclustlabels{end+1} = 'ig';
opts.pLoad={ 'lbls', {inclustlabels},'ilbls',{'ig'},'squarify',[]}; 
%%
opts.pJitter=struct('flip',0); opts.pNms.ovrDnm = 'union';
%opts.pPyramid.nPerOct=10;
opts.pPyramid.pChns.pGradHist.softBin=1;
opts.pPyramid.pChns.pColor.smooth=0;
opts.pBoost.pTree.maxDepth=2;
opts.pPyramid.pChns.shrink =2; %2 or 4. 2 gives better accuracy. 4 is fast. 

detector = acfTrain_subcat(opts);
end
%%
%Load trained detectors. 
clear dets
opts = []; opts.pNms.type  = 'maxg'; opts.pNms.ovrDnm  = 'union';  opts.pNms.overlap = 0.3;
for ori_i = 1:B
    currname=[outdir '/model' sprintf('%02d',ori_i)];
    currdet = load([currname 'Detector.mat']);
    currdet = acfModify(currdet.detector,'cascThr',-1,'cascCal',0,'pNms', opts.pNms);
    currdet.opts.pPyramid.nPerOct=10;
    dets{ori_i} = currdet;
end
%%
%Test on an image
I = imread([outdir '/pos/000006.png']);
bbs = acfDetect(I,dets);
imshow(I); bbApply('draw',bbs);