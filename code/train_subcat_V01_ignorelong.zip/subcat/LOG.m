%Version History

% Ver 0.0: 12/5/2014 - first release

% Ver 0.1: 12/22/2014 - minor fixes to acfTrain in how subcategory samples
% are excluded. For instance, 'compOas' doesn't work correctly for `ignore'
% boxes. For instance try the following experiments.

% 'detected' bounding boxes
%  bbs =[         1            1           54           32
%                 1          172           54           32
%                 1          343           54           32
%            132.89            1           54           32
%            132.89          172           54           32
%            132.89          343           54           32
%            264.78            1           54           32
%            264.78          172           54           32
%            264.78          343           54           32
%            396.67            1           54           32
%            396.67          172           54           32
%            396.67          343           54           32
%            528.56            1           54           32
%            528.56          172           54           32
%            528.56          343           54           32
%            660.44            1           54           32
%            660.44          172           54           32
%            660.44          343           54           32
%            792.33            1           54           32
%            792.33          172           54           32
%            792.33          343           54           32
%            924.22            1           54           32
%            924.22          172           54           32
%            924.22          343           54           32
%            1056.1            1           54           32];

% ground truth boxes with ignore flags
% gt = [4 203 342 171 1; 521 138 84 58 1; 395 176 41 32 0];  
% and run the discarding script ('compOas' does not correctly discard
% ignore flags
% n=size(bbs,1); keep=false(1,n); for i=1:n, keep(i)=all(bbGt('compOas',bbs(i,:),gt,gt(:,5))<.1); end
% vs. 
% ground truth boxes as they are
% gt = [395 176 41 32 0];  



% TODO: Add visual clustering code. 