pmtroot ='C:\toolbox-master\';   %SET PIOTR'S TOOLBOX PATH
addpath(genpath(pmtroot));

kittiroot = 'C:\KITTI\devkit_obj';   %SET DEVELOPMENT KIT FOR KITTI    
kittiobjectroot = 'C:/KITTI/object_challenge/'; %Where 'image_2' and 'label_2' are
addpath(genpath(kittiroot));

rootlabels = fullfile(kittiobjectroot,'labels_2/training/label_2');
rootims = fullfile(kittiobjectroot,'image_2/training/image_2');

%We use `moderate' settings in training. 
minboxheight = 25;
occlusionLevel = [0:1]; % [0:2] 0 = fully visible, 1 = partly occlud 2 = largely occluded, 3 = unknown
Maxtruncation = 0.3; % Percentage, from 0 to 1.
labels = {'Car'}; %can do {'Car','Truck','Van'} for adding these to training, but not needed for KITTI evaluation
B = 25; %Number of orientation clusters. Up to 20-25 should increase performance.
